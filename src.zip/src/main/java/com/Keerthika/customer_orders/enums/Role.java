package com.Keerthika.customer_orders.enums;

/**
 * @author Keerthika
 */
public enum Role {
    ADMIN,
    CUSTOMER
}
